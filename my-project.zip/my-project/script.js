
document.addEventListener("DOMContentLoaded", function () {
  console.log("Дані персонажів завантажені!");
});
